// emission factors (rough averages, kg CO2e per unit)
const FACTORS = {
  electricity: 0.43, // per kWh
  car: 0.21,         // per km
  flights: 90,       // per flight hour short-haul
  meat: 27           // per kg
};

document.getElementById('year').textContent = new Date().getFullYear();

document.getElementById('calcForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const electricity = parseFloat(document.getElementById('electricity').value) || 0;
  const car = parseFloat(document.getElementById('car').value) || 0;
  const flights = parseFloat(document.getElementById('flights').value) || 0;
  const meat = parseFloat(document.getElementById('meat').value) || 0;

  const footprint =
    electricity * FACTORS.electricity +
    car * FACTORS.car +
    flights * FACTORS.flights +
    meat * FACTORS.meat;

  // Show result
  const output = document.getElementById('output');
  output.innerHTML = `<strong>Your estimated monthly footprint is ${footprint.toFixed(1)} kg CO₂e.</strong>`;

  // Suggestions
  let suggestions = [];
  if (electricity > 300) {
    suggestions.push("⚡ Switch to LED bulbs, turn off appliances when not in use, and consider renewable energy.");
  }
  if (car > 400) {
    suggestions.push("🚗 Use public transport, carpool, cycle, or walk more often to cut car emissions.");
  }
  if (flights > 1) {
    suggestions.push("✈️ Reduce air travel when possible, choose trains/buses, or offset flight emissions.");
  }
  if (meat > 8) {
    suggestions.push("🥗 Try reducing red meat consumption and add more plant-based meals to your diet.");
  }
  if (suggestions.length === 0) {
    suggestions.push("✅ Great job! Your footprint is already low. Keep up eco-friendly habits!");
  }

  const suggestionBox = document.createElement("ul");
  suggestionBox.classList.add("tips");
  suggestions.forEach(tip => {
    let li = document.createElement("li");
    li.textContent = tip;
    suggestionBox.appendChild(li);
  });

  output.appendChild(suggestionBox);

  document.getElementById('result').classList.remove('hidden');
});

